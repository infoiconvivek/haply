<?php /* Template Name: Solutions Page*/ get_header();?>
<section class="about">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8">
                    <div class="about_sec">
                        <img src="<?= bloginfo('template_url')?>/assets/img/coming-soon.png" alt="" class="img-fluid com__son">

                        <div class="line" data-wow-delay=".7s"></div>
                        <h1 class="h1">Great things coming soon...!</h1>
                        <p class="wow slideInUp">We are small and growing consulting firm with big ideas.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
<?php get_footer();?>