<?php /*Template Name: Home*/
get_header();
echo THEME_NAME;
if (THEME_NAME == 'black') {
    get_template_part('home', THEME_NAME);
} else {
    get_template_part('home', THEME_NAME);
}
?>
<section class="feature">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-sm-12">
                <div class="about_sec">
                    <div class="line"></div>
                    <h1 class="h1"><?php echo get_field('related_article_heading'); ?></h1>

                </div>
            </div>
        </div>
        <div class="row">
            <?php

            $meta_query = array(
                array(
                    'key'     => 'manage_theme',
                    'value'   => THEME_NAME ? THEME_NAME : 'green', // THEME_NAME come form wp_config.php 
                    'compare' => 'LIKE',
                )
            );


            $args = array(
                'post_type' => 'epkb_post_type_1', // Your custom post type
                'posts_per_page' => '3', // Change the number to whatever you wish
                'meta_query' => $meta_query,
            );
            $new_query = new WP_Query($args);
            if ($new_query->have_posts()) :
                while ($new_query->have_posts()) :
                    $new_query->the_post();
            ?>
                    <div class="col-lg-4">
                        <div class="feature-box">
                            <div class="img-style">
                                <?php if (has_post_thumbnail()) {
                                    the_post_thumbnail();
                                } else {
                                    $upload_dir   = wp_upload_dir();
                                    echo '<img class="img-fluid" src="' . $upload_dir['baseurl'] . '/2023/06/about-img1.png"/>';
                                } ?>

                            </div>

                            <div class="content-style">
                                <h2><?php the_title(); ?></h2>
                                <h4><?php echo wp_trim_words(get_the_excerpt(), '10', '...'); ?></h4>


                                <div class="user">
                                    <div class="user-img">
                                        <?php $theAuthorId = get_the_author_meta('ID'); ?>
                                        <?php echo get_avatar($theAuthorId); ?>
                                    </div>

                                    <div class="user-info">
                                        <h4><?php echo get_author_name(); ?></h4>
                                        <h4><?php echo get_the_date(); ?></h4>
                                    </div>
                                </div>

                                <a href="<?php echo get_post_permalink(); ?>" class="btn custom-btn"><?php esc_html_e('Read more', 'HaplyWP') ?></a>
                            </div>
                        </div>
                    </div>
            <?php endwhile;
                wp_reset_postdata();
            endif ?>

            <div class="col-lg-12">
                <div class="text-center">
                    <a href="<?php echo get_field('related_article_button')['url'];  ?>" class="btn hover-btn featureBtn"><?php echo get_field('related_article_button')['title'] ? get_field('related_article_button')['title'] : 'See all how-to articles'; //esc_html_e( 'See all how-to articles', 'HaplyWP' )
                                                                                                                            ?> </a>

                </div>

            </div>
        </div>
    </div>
</section>

<?php
get_footer();
