var el = wp.element.createElement;
var Button = wp.components.Button;

wp.blocks.registerBlockType('gutenberg-notice-block/user-designation-block', {
    title: 'User Designation Block',
    icon: 'admin-users',
    category: 'common',
    attributes: {
        title: { type: 'string' },
        users: { type: 'array', default: [] }
    },
    edit: function (props) {
        // Ensure user data is fetched
        let [userData, setUserData] = wp.element.useState([]);
        // var userData2 = wp.data.select('core').getEntityRecords('root', 'user')|| [];
        const { subscribe, select } = wp.data;

        // Fetch users list.

        const unsubscribe = subscribe(() => {
            const { isResolving } = select('core/data');
            const args = ['root', 'user'];

            if (isResolving('core', 'getEntityRecords', args)) {
                console.log('still resolving');
            } else {
                const data = select('core').getEntityRecords('root', 'user');
                console.log('data received', data);
                if (data && data?.length > 0) setUserData(data)

                console.log('userData', userData)
                // We're done, so let's unsubscribe from the isResolving() check above.
                unsubscribe();
            }
        });



        wp.element.useEffect(() => {
            // Fetch user data when component mounts or when props are updated
            // var userRecords = wp.data.select('core').getEntityRecords('root', 'user');
            // var userData = wp.data.select('core').getEntityRecords('root', 'user') || [];
            // console.log(userData);
            // setUserData(userData);
            // if (userRecords !== null) {
            //     userRecords.then(users => {
            //         setUserData(users || []);
            //     });
            // } else {
            //     setUserData([]); // Reset user data if userRecords is null
            // }
        }, [props.attributes.users]); // Re-fetch user data when user list is updated

        // Function to handle updating title
        function updateTitle(event) {
            props.setAttributes({ title: event.target.value });
        }

        // Function to handle adding a new user
        function addUser() {
            var updatedUsers = [...props.attributes.users, { userId: '', designation: '' }];
            props.setAttributes({ users: updatedUsers });
        }

        // Function to handle updating user ID
        function updateUser(userId, index) {
            var updatedUsers = [...props.attributes.users];
            updatedUsers[index].userId = userId;
            props.setAttributes({ users: updatedUsers });
        }

        // Function to handle updating designation
        function updateDesignation(designation, index) {
            var updatedUsers = [...props.attributes.users];
            updatedUsers[index].designation = designation;
            props.setAttributes({ users: updatedUsers });
        }

        // Function to handle removing a user
        function removeUser(index) {
            var updatedUsers = [...props.attributes.users];
            updatedUsers.splice(index, 1);
            props.setAttributes({ users: updatedUsers });
        }

        // Map users to input fields
        var userFields = props.attributes.users.map(function (user, index) {
            return wp.element.createElement('div', { key: index },
                wp.element.createElement('select', {
                    value: user.userId,
                    onChange: function (event) { updateUser(event.target.value, index); },
                    className: 'user-dropdown',
                }, userData.map(function (user) {
                    return wp.element.createElement('option', { key: user.id, value: user.id }, user.name);
                })),
                wp.element.createElement('input', {
                    type: 'text',
                    value: user.designation,
                    onChange: function (event) { updateDesignation(event.target.value, index); },
                    placeholder: 'Enter designation...',
                    className: 'designation-field'
                }),
                wp.element.createElement(Button, {
                    isDestructive: true,
                    onClick: function () { removeUser(index); }
                }, 'Remove')
            );
        });

        return wp.element.createElement('div', null,
            wp.element.createElement(Button, { onClick: addUser }, 'Add User'),
            wp.element.createElement('input', {
                type: 'text',
                placeholder: 'Write your title here...',
                value: props.attributes.title,
                onChange: updateTitle,
                style: { width: '100%' }
            }),
            userFields
        );
    },
    save: function (props) {
        const { useState, useEffect } = wp.element;
        const [userDetails, setUserDetails] = useState([]);
        const { subscribe, select } = wp.data;
    
        useEffect(() => {
            async function fetchUserDetails() {
                const unsubscribe = subscribe(() => {
                    const { isResolving } = select('core/data');
                    const args = ['root', 'user'];
        
                    if (isResolving('core', 'getEntityRecords', args)) {
                        console.log('still resolving');
                    } else {
                        const data = props.attributes.users.map(user =>{ 
                            const mydata = select('core').getEntityRecords('root', 'user', user.userId)
                            console.log('mydata', mydata)
                        });
                        // const data = select('core').getEntityRecords('root', 'user');
                        console.log('data received', data);
                        if (data && data?.length > 0) setUserData(data)
        
                        console.log('userData', userData)
                        // We're done, so let's unsubscribe from the isResolving() check above.
                        unsubscribe();
                    }
                });
                // const userPromises = props.attributes.users.map(user => wp.data.select('core').getEntityRecords('root', 'user', user.userId));

                // try {
                //     const userData = await Promise.all(userPromises);
                //     console.log('userData', userData)
                //     setUserDetails(userData);
                // } catch (error) {
                //     console.error('Error fetching user data:', error);
                // }
            }
    
            fetchUserDetails();
        }, [props.attributes.users]);
    
        // Render user details
        const userElements = userDetails.map((user, index) => {
            return (
                wp.element.createElement('div', { className: 'col-xl-3 col-lg-4 col-md-6', key: index },
                    wp.element.createElement('div', { className: 'supporters' },
                        wp.element.createElement('div', { className: 'img-wrap' },
                            user && user.avatar_urls && wp.element.createElement('img', { src: user.avatar_urls['96'], alt: user.name })
                        ),
                        wp.element.createElement('div', { className: 'user-info' },
                            user && user.name && wp.element.createElement('p', { className: 'fw-bold' }, user.name),
                            wp.element.createElement('p', null, props.attributes.users[index].designation)
                        )
                    )
                )
            );
        });
    
        return (
            wp.element.createElement('section', { className: 'module-supporters' },
                wp.element.createElement('div', { className: 'container-fluid' },
                    wp.element.createElement('div', { className: 'row' },
                        wp.element.createElement('div', { className: 'col-lg-12' },
                            wp.element.createElement('div', { className: 'content-left' },
                                wp.element.createElement('h2', null, props.attributes.title)
                            )
                        ),
                        // Render user elements
                        ...userElements
                    )
                )
            )
        );
    }
    
});