
  I18n for Echo Knowledge Base
  ============================
  
  Do not put custom translations here. They will be deleted when this plugin is updated !!!
  
  Instead please join our WP-Translations Community at
  https://translate.wordpress.org/locale/en-ca/default/wp-plugins/echo-knowledge-base

  More info at http://wp-translations.org/
