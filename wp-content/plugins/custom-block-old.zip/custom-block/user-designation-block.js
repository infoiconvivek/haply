var el = wp.element.createElement;
var Button = wp.components.Button;

wp.blocks.registerBlockType('gutenberg-notice-block/user-designation-block', {
    title: 'User Designation Block',
    icon: 'admin-users',
    category: 'common',
    attributes: {
        title: { type: 'string' },
        users: { type: 'array', default: [] }
    },
    edit: function (props) {
        // Ensure user data is fetched
        var [userData, setUserData] = wp.element.useState([]);

        wp.element.useEffect(() => {
            // Fetch user data when component mounts or when props are updated
            var userRecords = wp.data.select('core').getEntityRecords('root', 'user') || [];
            
            console.log(userRecords);
            setUserData(userRecords);
            props.setAttributes({ users: props.attributes.users });
            //var userRecords = wp.data.select('core').getEntityRecords('root', 'user');
            // if (userRecords !== null) {
            //     userRecords.then(users => {
            //         setUserData(users || []);
            //     });
            // } else {
            //     setUserData([]); // Reset user data if userRecords is null
            // }

        }, [props.attributes.users]); // Re-fetch user data when user list is updated

        // Function to handle updating title
        function updateTitle(event) {
            props.setAttributes({ title: event.target.value });
        }

        // Function to handle adding a new user
        function addUser() {
            var updatedUsers = [...props.attributes.users, { userId: '', designation: '' }];
            props.setAttributes({ users: updatedUsers });
        }

        // Function to handle updating user ID
        function updateUser(userId, index) {
            var updatedUsers = [...props.attributes.users];
            updatedUsers[index].userId = userId;
            props.setAttributes({ users: updatedUsers });
        }

        // Function to handle updating designation
        function updateDesignation(designation, index) {
            var updatedUsers = [...props.attributes.users];
            updatedUsers[index].designation = designation;
            props.setAttributes({ users: updatedUsers });
        }

        // Function to handle removing a user
        function removeUser(index) {
            var updatedUsers = [...props.attributes.users];
            updatedUsers.splice(index, 1);
            props.setAttributes({ users: updatedUsers });
        }

        // Map users to input fields
        var userFields = props.attributes.users.map(function (user, index) {
            return wp.element.createElement('div', { key: index },
                wp.element.createElement('select', {
                    value: user.userId,
                    onChange: function (event) { updateUser(event.target.value, index); },
                    className: 'user-dropdown',
                }, userData.map(function (user) {
                    return wp.element.createElement('option', { key: user.id, value: user.id }, user.name);
                })),
                wp.element.createElement('input', {
                    type: 'text',
                    value: user.designation,
                    onChange: function (event) { updateDesignation(event.target.value, index); },
                    placeholder: 'Enter designation...',
                    className: 'designation-field'
                }),
                wp.element.createElement(Button, {
                    isDestructive: true,
                    onClick: function () { removeUser(index); }
                }, 'Remove')
            );
        });

        return wp.element.createElement('div', null,
            wp.element.createElement(Button, { onClick: addUser }, 'Add User'),
            wp.element.createElement('input', {
                type: 'text',
                placeholder: 'Write your title here...',
                value: props.attributes.title,
                onChange: updateTitle,
                style: { width: '100%' }
            }),
            userFields
        );
    },
    save: function (props) {
        return el('section', { className: 'module-supporters' },
            el('div', { className: 'container-fluid' },
                el('div', { className: 'row' },
                    el('div', { className: 'col-lg-12' },
                        el('div', { className: 'content-left' },
                            el('h2', null, props.attributes.title)
                        )
                    ),
                    props.attributes.users.map(function (user, index) {
                        var userRecord = wp.data.select('core').getEntityRecord('root', 'user', user.userId) || {};
                        return el('div', { className: 'col-xl-3 col-lg-4 col-md-6', key: index },
                            el('div', { className: 'supporters' },
                                el('div', { className: 'img-wrap' },
                                    userRecord && userRecord.avatar_urls && el('img', { src: userRecord.avatar_urls['96'], alt: userRecord.name })
                                ),
                                el('div', { className: 'user-info' },
                                    userRecord && userRecord.name && el('p', { className: 'fw-bold' }, userRecord.name),
                                    el('p', null, user.designation)
                                )
                            )
                        );
                    })
                )
            )
        );
    }
});